O que fazer se a fonte do formato SVG está errada?
O motivo é simples.
A fonte é exibida incorretamente porque ela não está instalada na biblioteca de fontes do seu sistema operacional.
Descubra como resolver este problema neste artigo: https://www.logaster.com.br/blog/wrong-svg.